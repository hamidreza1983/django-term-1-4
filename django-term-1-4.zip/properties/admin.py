from django.contrib import admin
from .models import *

admin.site.register(Properties)
admin.site.register(Type)
admin.site.register(Method)

# Register your models here.
