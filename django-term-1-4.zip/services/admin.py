from django.contrib import admin
from .models import Services, Special_services, Category, Comments

admin.site.register(Services)
admin.site.register(Special_services)
admin.site.register(Category)
admin.site.register(Comments)




# Register your models here.
